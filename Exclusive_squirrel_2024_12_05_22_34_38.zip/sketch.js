

function setup() {
  createCanvas(900, 900);
}

function draw() {
  background(220);
  fill(255, 0, 0);
  rect(0, 700, 400, 50);
  rect(600, 700, 400, 50);
  rect(200, 600, 20, 20);
  
  fill(150, 100, 0);
  rect(200, 640, 30, 50);
  rect(260, 620, 10, 10);
  rect(260, 640, 10, 50);
  rect(200, 690, 10, 10);
  rect(220, 690, 10, 10);
  
  fill(255);
  rect(200, 610, 30, 30);
  rect(190, 640, 10, 40);
  rect(230, 640, 40, 10);
   rect(660, 640, 40, 50);
  rect(660, 680, 10, 20);
  rect(690, 680, 10, 20);
  
  
  
  
  
  fill(200);
  rect(258, 630, 30, 10);
  rect(280, 630, 20, 30);
  
  fill(255, 255, 0);
    rect(660, 600, 40, 40);
     rect(700, 640, 15, 40);
    rect(630, 640, 30, 15);
  
    fill(0)
  rect(205, 615, 5, 10);
  rect(220, 615, 5, 10);
  rect(690, 610, 5, 10);
    rect(665, 610, 5, 10);
    
  
  fill(0, 255, 255)
  let x = frameCount % 900;

  // If the mouse is pressed,
  // decrease the frame rate.
  if (mouseIsPressed === true) {
    frameRate(10);
  } else {
    frameRate(60);
  }

  // Use x to set the circle's
  // position.
  ellipse(x+50, 550, 60, 20);
   ellipse(x+70, 750, 60, 20);
  ellipse(x, 650, 60, 20);
  
 
  
  fill(255, 200, 0)
  let z = frameCount % 900
   if (mouseIsPressed === false) {
    frameRate(10);
  } else {
    frameRate(60);
     ellipse(280, x+20, z, 20);
   ellipse(370, x-50, z, 20);
  ellipse(450, x, z, 20);
     {
   fill(255, 255, 0)
textSize(40)
  textAlign(CENTER);
      if (mouseIsPressed === true){
      text('You have made a terrible mistake Kratos', 400, 500)
}

  }  
    
    
    
   
      //text
 
 fill(255, 0, 0);
  textSize(40)
  textAlign(CENTER);
  text('Zeus Your Son has Returned', 400, 320);
  
   
   
    
   
  
}

}